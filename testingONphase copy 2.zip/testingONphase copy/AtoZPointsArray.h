//
//  AtoZPointsArray.h
//  testingONphase
//
//  Created by  BSA univ 26 on 16/07/14.
//  Copyright (c) 2014 BSA univ 9. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AtoZPointsArray : NSObject

{
     @public NSArray *points;
}
-(NSArray*) APointsArray;
-(NSArray*) BPointsArray;
-(NSArray*) CPointsArray;
-(NSArray*) DPointsArray;
-(NSArray*) EPointsArray;
-(NSArray*) FPointsArray;
-(NSArray*) GPointsArray;
-(NSArray*) HPointsArray;
-(NSArray*) IPointsArray;
-(NSArray*) JPointsArray;
-(NSArray*) KPointsArray;
-(NSArray*) LPointsArray;

-(NSArray*) MPointsArray;
-(NSArray*) NPointsArray;
-(NSArray*) OPointsArray;
-(NSArray*) PPointsArray;


-(NSArray*) QPointsArray;
-(NSArray*) RPointsArray;
-(NSArray*) SPointsArray;
-(NSArray*) TPointsArray;

-(NSArray*) UPointsArray;
-(NSArray*) VPointsArray;
-(NSArray*) WPointsArray;
-(NSArray*) XPointsArray;
-(NSArray*) YPointsArray;
-(NSArray*) ZPointsArray;

@end
