//
//  KidName.h
//  testingONphase
//
//  Created by BSA univ 9 on 11/08/14.
//  Copyright (c) 2014 BSA univ 9. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface KidName : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * no;

@end
