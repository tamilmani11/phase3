//
//  KidName.m
//  testingONphase
//
//  Created by BSA univ 9 on 11/08/14.
//  Copyright (c) 2014 BSA univ 9. All rights reserved.
//

#import "KidName.h"


@implementation KidName

@dynamic name;
@dynamic no;

@end
